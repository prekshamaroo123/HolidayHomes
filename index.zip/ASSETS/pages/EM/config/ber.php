<?php
header("refresh:2; url=../cancel.php");

?>
<!DOCTYPE html>
<html>
<head>
    <title>Answer Updated</title>
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet" >
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../css/wc.css">
    <link rel="stylesheet" href="../../css/main.css">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/bootstrap.css">
   
    <style>
        body{
            padding-top:25px;
        }
        .container{
            padding-bottom: 25px;
        }

    </style>    
</head>
<body>
<div class="container" style="padding-bottom: 25px;"><br><br>
            <div class="alert alert-success" role="alert">       
            <h4>You have succesfully Updated Your Answer. </h4>
            </div>
    </div>    




</body>
</html>