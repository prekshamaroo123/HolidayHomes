<?php

//MySQLi connection
include("connect.php");
//starting our session to preserve our login
session_start();


//check whether data with the name username has been submitted
if (isset($_POST['ans1'])) {

	//variables to hold our submitted data with post
$ques_1 = $_POST['ans1'];
$ques_2 = $_POST['ans2'];
$_SESSION['id'] = $_POST["emp_id"];
$id = $_POST["emp_id"];


	//our sql statement that we will execute
	$sql = "SELECT * FROM emp_details WHERE emp_id='$id' AND ans1='$ques_1' AND ans2='$ques_2'";

	//Executing the sql query with the connection
	$re = mysqli_query($con, $sql);


	//check to see if there is any record or row in the database if there is then the user exists
	if (mysqli_num_rows($re)) 
                
                {
               header("Location: ../update.php");
         	}

                else
                {
		header("Location: invldcred.php");
	        }
}
?>





