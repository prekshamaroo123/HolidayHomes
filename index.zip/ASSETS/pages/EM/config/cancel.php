<?php

//MySQLi connection
$con =mysqli_connect('127.0.0.1','root','','bms');

// Check connection for any errors
if (mysqli_connect_errno()){
echo "Failed to connect to MySQL: ".mysqli_connect_error();
}
session_start();
$value = $_SESSION['bookingid'];
mysqli_query($con," UPDATE emp_history SET cancel='1' WHERE b_id='$value'");
mysqli_query($con," UPDATE udaipur_rh SET res_flag='0' WHERE b_id='$value'");
mysqli_query($con," UPDATE udaipur_rh SET b_id='0' WHERE b_id='$value'");
?>
<?php
header("refresh:2; url=../cancel.php");

?>
<!DOCTYPE html>
<html>
<head>
    <title>Succesfully Cancelled </title>
     <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../../css/wc.css">
    <link rel="stylesheet" href="../../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../../css/bootstrap.css">
    <meta name="viewport" content="width-device-width,initial-scale=1.0 user-scale=no">
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <style>
        body{
            padding-top:25px;
        }
        .container{
            padding-bottom: 25px;
        }

    </style>    
</head>
<body>
<div class="container" style="padding-bottom: 25px;"><br><br>
            <div class="alert alert-success" role="alert">   
                <h1>Succesfully Cancelled</h1>
            <h4>You have succesfully Cancelled Your Booking </h4>
            </div>
    </div>    




</body>
</html>