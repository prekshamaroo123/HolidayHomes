<?php
            include("connect.php");
            session_start ();
      $oldpass=$_POST['npwd'];
      $useremail=$_SESSION['id'];
      $newpassword=$_POST['cpwd'];
      $sql = mysqli_query($con,"SELECT pswd FROM emp_details where emp_id='$useremail'");
          $row = mysqli_fetch_array($sql);
          if($newpassword == $oldpass)
          {
          mysqli_query($con,"UPDATE emp_details set pswd='$newpassword' where emp_id='$useremail'");

          header("Location: ../PswdChngd.php");
          }
        else{
            header("Location: ../ErPswdChngd.php");
         }

      

?>