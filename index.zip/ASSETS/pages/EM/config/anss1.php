<?php 
include("connect.php");
session_start ();
$empid = $_SESSION['empid'];
if (isset($_POST['submit'])) {
$ans1 = $_POST['anss'];
$sql = mysqli_query($con,"UPDATE emp_details set ans1='$ans1' where emp_id='$empid'");
if (mysqli_num_rows($sql) == 0){

    header("Location: ../AnsChngd.php");
}
else{
    header("Location: ../ErAnsChngd.php");
 }

}
?>
