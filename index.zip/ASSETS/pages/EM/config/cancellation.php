    <!DOCTYPE html>
<html>
<head>

    <title>Request A Cancellation</title>
     <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../../css/wc.css">
    <link rel="stylesheet" href="../../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../../css/bootstrap.css">
    <meta name="viewport" content="width-device-width,initial-scale=1.0 user-scale=no">
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    </head>
    <style>
        body{
            padding-top:50px;
            padding-bottom:25px;
        }
        .container{
            padding-top:25px;
            padding-bottom: 25px;
        }
    </style>
    <body>
        <?php
        include('../../../head/header.html');
        ?>
        
         
<?php
//MySQLi connection
$con =mysqli_connect('127.0.0.1','root','','bms');

// Check connection for any errors
if (mysqli_connect_errno()){
echo "Failed to connect to MySQL: ".mysqli_connect_error();
}
//starting our session to preserve our login
session_start();
//check whether data with the name username has been submitted
if (isset($_POST['bookid'])) {

	//variables to hold our submitted data with post
	$book_id = $_POST['bookid'];
    $_SESSION['bookingid'] = $book_id; 
    $sql = "SELECT * FROM emp_history WHERE b_id='$book_id'";
    $result = mysqli_query($con,"SELECT * FROM emp_history WHERE b_id='$book_id'");
    $re = mysqli_query($con, $sql);

	//check to see if there is any record or row in the database if there is then the user exists
	if (mysqli_num_rows($re)) {
            //    echo "<p>Welcome</p>";
        while($row = mysqli_fetch_array($result)){
        {
            $idemp = $row["emp_name"]; 
            $kya = $row["typee"];
            $kab = $row["date_of_booking"];
            $kabse = $row["_from"];
            $kabtk = $row["_to"];
            $kabtk = $row["_to"];
            $kha = $row["locatn"];
            $sts = $row["cancel"];
            
            
        }
            
        	}}
    else{
		       header("Location: berr.php");
	        }}

    ?>

        
        <div class="container" style="padding-bottom:25px;">
            <a href="../cancel.php" class="btn btn-danger" type="" role="button">Back</a><br><br>
        <center><h2>Cancel</h2>
            <h6> Press Confirm To Cancel the Booking </h6>
            <table>
            <tbody> 
                <tr>
                    <th> Booking ID</th>
                    <td> <?php echo $book_id; ?></td>
                </tr>
                <tr>
                    <th> Date Of Booking :</th>
                    <td> <?php echo $kab; ?></td>
                </tr>
                <tr>
                    <th> Name :</th>
                    <td><?php echo $idemp; ?></td>
                </tr>
                <tr>
                    <th> Type:</th>
                    <td> <?php echo $kya; ?></td>
                </tr>
                <tr>
                    <th> Location :</th>
                    <td> <?php echo $kha; ?></td>
                </tr>
                <tr>
                    <th> From :</th>
                    <td> <?php echo $kabse; ?></td>
                </tr>
                <tr>
                    <th> To :</th>
                    <td> <?php echo $kabtk; ?></td>
                </tr>
                <tr>
                    <th>Status :</th>
                    <td><?php 
               if($sts==0){
                   echo "Confirmed";
               }
               else{
                   echo "Cancelled";
               }
               
                ?>
                    </td>
                </tr>
                <tr align="center">
                <td align="center"><a href="cancel.php" class="btn btn-primary btn-sm" 
                                      <?php if($sts==1){
                                                echo "hidden";
                                      }
                                      else{ 
                                          echo ">";
                                      }
                                      ?>
                                      Confirm Cancellation </a></td>
                </tr>
                
                </tbody>
            </table>
            </center>
        </div>
        
    <?php
        include('../../../head/footer.html');
        ?>
    </body>
    
</html>
        