<?php
include("connect.php");
$loctn = $_POST['lctn'];

$loca =$loctn."_rh";
$date3=  date("d-m-Y");
$date3= strtotime($date3);
$date = strtotime($_POST['date']);
$date4=$_POST['date'];
$date1=$date+86400;
$date2=$date1+86400;
if ($date>$date3)
{
    
//$sql = "SELECT _from,_to,pay FROM table1 ";
$sql = "SELECT * FROM $loca";
    $result = mysqli_query($con,"SELECT * FROM $loca");
   $count=0;
    $count1=0;
    $count2=0;
   $total=0;
	//Executing the sql query with the connection
	$re = mysqli_query($con, $sql);

	//check to see if there is any record or row in the database if there is then the user exists
	if (mysqli_num_rows($re)) {
                while($row = mysqli_fetch_array($result)){
        {
            $from=strtotime($row["_from"]);
            $to= strtotime($row["_to"]);
            if ($row["id"]>0)
                {
                    $total++;
                }
            if (($date>=$from)and($date<=$to))
            {
                if ($row["res_flag"]==1)
                {
                    $count++;
                }
            }
            if (($date1>=$from)and($date1<=$to))
            {
                if ($row["res_flag"]==1)
                {
                    $count1++;
                }
            }
            if (($date2>=$from)and($date2<=$to))
            {
                if ($row["res_flag"]==1)
                {
                    $count2++;
                }
            }
            
        }
                    
    }
        $CurDate = date('d-m-Y', strtotime("$date4"));
        $CurudrAbl = $total-$count;
        $CurOdate = date('d-m-Y', strtotime("$date4 +1 day"));
        $CurudrOavbl = $total-$count1; 
        $CurTdate = date('d-m-Y', strtotime("$date4 +2 day"));
        $CurudrTavbl = $total-$count2;
         	}
    else{
		        header("Location: inv.php");
	        }
}
else
{
    header("Location: er.fut.php");
}
?>
<DOCTYPE html>
<html>
    <head>
        <title> Availibilty - Holiday Homes </title>
         <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../../css/wc.css">
    <link rel="stylesheet" href="../../../css/main.css">
    <link rel="stylesheet" href="../../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../../css/bootstrap.css">
    <meta name="viewport" content="width-device-width,initial-scale=1.0 user-scale=no">
        <style>
        body{
            padding-top:25px;
        }
        .container{
            padding-top:25px;
            padding-bottom:25px;
        }

    </style>
    </head>
    <body>       
        <div class="container"><center>
            <h3>Availibilty Of Rest House</h3>
            <p>The number of rooms availble in Rest House </p></center>
            <a href="../../EM/avbl.php" class="btn btn-danger" type="" role="button">Back</a><br><br>
            <!--<center><form action="" mrthod="post">
                <label for="">Choose Date : </label>
                <input type="date" name="c_date" />
                <button type="submit" class="btn btn-info btn-sm">Check</button>
            </form></center>-->

        </div>
        <div class="container">
        <table class="table table-borderd">
        <thead>
            <tr>
                <th>
                    Location 
                </th>
                <th>
                  <?php echo $CurDate; ?>
                </th>
                <th>
                   <?php echo $CurOdate ; ?>
                </th>
                <th>
                   <?php echo $CurTdate ; ?>
                </th>
                <th> Link
                </th>

            </tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <?php  echo $loctn; ?>
                </td>
                <td>
                <?php  echo $CurudrAbl; ?>
                </td>
                <td>
                <?php  echo $CurudrOavbl; ?>
                </td>
                <td>
                    <?php  echo $CurudrTavbl; ?>
                </td>
                <td><a href="../../RH/resthouse.php">BOOK</a></td>
            </tr>
            
            
        </tbody>


        </table>
        </div>

    </body>
</html>
