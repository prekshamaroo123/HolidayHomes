<?php 
include("connect.php");
session_start ();
$empid = $_SESSION['empid'];
if (isset($_POST['submit'])) {
$ans2 = $_POST['anss2'];
$sql = mysqli_query($con,"UPDATE emp_details set ans2='$ans2' where emp_id='$empid'");
if (mysqli_num_rows($sql) == 0){

    header("Location: ../AnsChngd.php");
}
else{
    header("Location: ../ErAnsChngd.php");
 }

}
?>
