<?php 

 
$con = mysqli_connect("localhost","root","","bms");

if (!$con) {
    die('Could not connect: ' . mysql_error());
}
else{
    //echo "Con ADM";
}


?>