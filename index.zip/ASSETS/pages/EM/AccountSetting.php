<!DOCTYPE html>
<html>
<head>
    <title>Account Settings</title>
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet" >
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../css/wc.css">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/bootstrap.css">
    <meta name="viewport" content="width-device-width,initial-scale=1.0 user-scale=no">
    <link rel="stylesheet" href="../../css/wc.css">
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet" >
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="../../css/wc.css">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <style>
         body{
            padding-top:25px;
        }
        .container{
            padding-bottom: 10px;
        }

    </style>    
</head>
    
    <body>
        <?php session_start(); 
        include('../../head/header.html');
        ?>
        <div class="container">
        <name class="row">
            <div class="col-md-3">
            <img  src="../../imgs/logo.png" alt="IRCTC" height="100" width="auto">
            </div>
            <div class="col-md-9">
                <h1>Account Setting</h1>
            </div>
        </name>
        <button onclick="goBack()" class="btn btn-danger">Back</button>
        <br><br>
        <center><h3 >Change Password</h3>
            <p><b>Changing password for : <a style="text-transform: uppercase;"> <?php echo "   ".$_SESSION["name"];?> </a></b></p>
        </center>
        <form name="chngpwd" action="config/pswdchng.php" method="post" onSubmit="return valid();">
            
        <div class="col-md-6">
  <div class="form-group">
    <label for="exampleInputCurrentPassword1">Current Password</label>
    <input type="password" class="form-control" placeholder="Enter Current Password" name="opwd" >
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">New Password</label>
    <input type="password" class="form-control" placeholder="Enter New Password" name="npwd" >
</div>
<div class="form-group">
    <label for="exampleInputPassword2">Confirm New Password</label>
    <input type="password" class="form-control" placeholder="Enter confirm Password" name="cpwd" >
  </div>
  <button type="submit"  class="btn btn-primary" name="submit">Update Password</button>
            </div>
</form>
<p><br><br></p>
 
 <h3>Update Security Questions</h3>
    <form name="chngpwd" action="config/anss1.php" method="post" >
    <div class="form-group">
        <div class="row">
            <div class="col-md-4"><label for="">What is Your Birth place ?</label><br></div>
            <div class="col-md-4"><input type="password" class="form-control" placeholder="Enter Birth Place" name="anss" required ><br></div>
            <div class="col-md-4"> <button type="submit" class="btn btn-primary" name="submit">Update Answer</button><br></div>
        </div>
    </div>
    </form>
    <form name="chngpwd" action="config/anss2.php" method="post" >
    <div class="form-group">
        <div class="row">
            <div class="col-md-4"><label for="">What is nick name ?</label><br></div>
            <div class="col-md-4"><input type="password" class="form-control" placeholder="Enter Nick Name" name="anss2"><br></div>
            <div class="col-md-4"> <button type="submit" class="btn btn-primary" name="submit">Update Answer</button><br></div>
        </div>
    </div>
    </form>
        <?php
       include('../../head/footer.html');
        ?>
<script type="text/javascript">
    function goBack() {
    window.history.back();
}
    function valid()
    {
    if(document.chngpwd.opwd.value=="")
    {
    alert("Old Password Filled is Empty !!");
    document.chngpwd.opwd.focus();
    return false;
    }
    else if(document.chngpwd.npwd.value=="")
    {
    alert("New Password Filled is Empty !!");
    document.chngpwd.npwd.focus();
    return false;
    }
    else if(document.chngpwd.cpwd.value=="")
    {
    alert("Confirm Password Filled is Empty !!");
    document.chngpwd.cpwd.focus();
    return false;
    }
    else if(document.chngpwd.npwd.value!= document.chngpwd.cpwd.value)
    {
    alert("Password and Confirm Password Field do not match  !!");
    document.chngpwd.cpwd.focus();
    return false;
    }
    return true;
    }
    </script>
            
        </div>
            
    </body>

</html>