<!DOCTYPE html>
<html>
<head>
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet" >
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../css/wc.css">
    <link rel="import" href="../head/header.php">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/bootstrap.css">
    <title>Welcome to IRCTC Online Booking</title>
    <meta name="viewport" content="width-device-width,initial-scale=1.0 user-scale=no">
    <link rel="stylesheet" href="../../css/wc.css">
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet" >
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="../../css/wc.css">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <script>
    history.pushState(null, null, location.href);
    window.onpopstate = function () {
        history.go(1);
    };
    </script>
     <script>
    history.pushState(null, null, location.href);
    window.onpopstate = function () {
        history.go(1);
    };
    </script>
    <style>
        body{
            padding-top:20px;
        }

    </style>
    </head>
    <body>
        
    <?php
       include('../../head/header.html');
       session_start();
        ?>
        <div class="container">
            <!--<nav class="row">
            <a class="col-md-3" href="accset.php">Account Settings</a>
            <a class="col-md-3" href="home.php">Booking</a>
            <a class="col-md-3" href="php/hist.php">History</a>
            <a class="col-md-3" href="logout.php">Log Out</a>
                        </nav>-->
            <name class="row">
             <div class="col-md-3">
                     <img src="../../images/logo.png"alt="IRCTC" height=150 width=auto>
            </div>
            <div class="col-md-9">
            <h1>Online Booking</h1>
            </div>
            </name>
        
        <div class="container" style=padding-top:25px;>
            <div class="row">
            <div class="col-md-3"> 
                <div class="sidenav">
                    <table>
                        <tbody>
                        <tr>
                            <td>
                            <button class="btn btn-light"size=20 ><a href="AccountSetting.php"> <i style="font-size: 35px;" class="fa fa-gear" aria-hidden="true"> </i><b>Settings</b></a></button>
                            </td>
                        </tr>
                        <tr>
                            <td>
                            <button class="btn btn-light" size=20><a href="booking.php"><i style="font-size:35px;" class="fa fa-building" aria-hidden="true"></i><b>Booking</b></a></button>
                            </td>
                        </tr>
                        <tr>
                            <td>
                            <button class="btn btn-light" size=20><a href="avbl.php"><i style="font-size: 35px;" class="fa fa-home" aria-hidden="true"></i><b>Check Availability</b></a></button>
                            </td>
                        </tr>
                            <tr>
                            <td>
                            <button class="btn btn-light" size=20><a href="../VR/vr.index.html"><i style="font-size: 35px;;" class="fa fa-child" aria-hidden="true"></i><b>VR Gallery</b></a></button>
                            </td>
                        </tr>
                            <tr>
                            <td>
                            <button class="btn btn-light" size=20 ><a href="review.html"><i style="font-size: 35px;;" class="fa fa-comment" aria-hidden="true"></i><b>Reviews</b></a></button>
                            </td>
                        </tr>
                            <tr>
                            <td>
                            <button class="btn btn-light" size=20 ><a href="history.php"><i style="font-size: 35px;;" class="fa fa-history" aria-hidden="true"></i><b>History</b></a></button>
                            </td>
                        </tr>
                            <tr>
                            <td>
                            <button class="btn btn-light" size=20 ><a href="cancel.php"><i style="font-size: 35px;" class="fa fa-ban" aria-hidden="true"></i><b>Cancel a Booking</b> </a></button><br>
                            </td>
                        </tr>
                            <tr>
                            <td>
                                <button class="btn btn-light" size=20><a href="javascript:myFunction()" color="red"><i style="font-size: 35px;" class="fa fa-power-off" aria-hidden="true"></i><b>Log Out</b></a></button>
                            </td>
                        
                        </tbody>
        </table>        
                </div>
            </div>
            <div class="col-md-9">
        <div class="alert alert-success" role="alert">
  <h4 class="alert-heading">Welcome, <?php echo "\n".$_SESSION["name"];?></h4>
  <p>You have succesfully logged in to your account.</p>
  <hr>
  <p class="mb-0">
  <div class="container" id="base">
          <div class="row">
              <div class="col-sm-4">
                <p><center> ID :  <?php echo "\n".$_SESSION["empid"];?></center></p>
              </div>
              <div class="col-sm-4">
                <p><center> NAME :  <?php echo "\n".$_SESSION["name"];?></center></p>
              </div>
              <div class="col-sm-4">
                <p><center> CLASS :  <?php echo "\n".$_SESSION["class"];?></center></p>  
              </div>
            </div>
      </div> 
              </div>
            </div>
            </div>
            </div>
        <script>
        function myFunction() {
            if (confirm("Are You Sure You Want To Log Out ")) {
                txt = "You Successfully Logged Out";
                document.location = 'logout.php';
                
               // document.location = 'php/lgt.php';
            } else {
                txt = "You are not Logged Out";
            }
        }
    </script>
            </div>
    <?php
       include('../../head/footer.html');
        ?>
    </body>
    
</html>