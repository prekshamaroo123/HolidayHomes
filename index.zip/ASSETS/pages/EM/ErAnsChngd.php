<?php
header("refresh:2; url=AccountSetting.php");

?>
<!DOCTYPE html>
<html>
<head>
    <title>OOPS - Error</title>
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet" >
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../css/wc.css">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/bootstrap.css">
    <meta name="viewport" content="width-device-width,initial-scale=1.0 user-scale=no">
    <link rel="stylesheet" href="../../css/wc.css">
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet" >
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="../../css/wc.css">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <style>
        body{
            padding-top:25px;
        }
        .container{
            padding-bottom: 25px;
        }

    </style>    
</head>
<body>
    <?php include('../../head/header.html');?>
<div class="container" style="padding-bottom: 25px;"><br><br>
            <div class="alert alert-danger" role="alert">       
            <h4>Some Error Occured !!!. </h4>
            <h5>Try Again After Some Time...</h5>
            </div>
    </div>    
    <?php include('../../head/footer.html');?>



</body>
</html>