<?php
/* Database credentials. Assuming you are running MySQL
*/
include("config/connect.php");
//starting our session to preserve our login
session_start();


//check whether data with the name username has been submitted
if (isset($_POST['empid'])) {

	//variables to hold our submitted data with post
	$emp_id = $_POST['empid'];
	$Password = ($_POST['Password']);
        
	//our sql statement that we will execute
	$sql = "SELECT * FROM emp_details WHERE emp_id='$emp_id' AND pswd='$Password'";
    $result = mysqli_query($con,"SELECT * FROM emp_details WHERE emp_id='$emp_id'");
   
	//Executing the sql query with the connection
	$re = mysqli_query($con, $sql);

	//check to see if there is any record or row in the database if there is then the user exists
	if (mysqli_num_rows($re)) 
	{
		$_SESSION['empid'] = $emp_id;
		//$_SESSION['name'] = $row["emp_name"];
		//$_SESSION['class'] = $row["class"]; 

        //echo "<p>Welcome</p>";
        while($row = mysqli_fetch_array($result)){
            //echo "\n".$row["emp_id"];
            //echo "\n".$row["emp_name"];
			//echo "\n".$row["class"];   
			$_SESSION['name'] = $row["emp_name"];
			$_SESSION['class'] = $row["class"]; 
			header("Location: welcome.php");
    	}
    }
    else{
		 header("Location: wc.er.php");
	    }
}
?>