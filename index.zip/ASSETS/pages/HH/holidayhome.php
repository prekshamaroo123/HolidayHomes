<!DOCTYPE html>
<html>
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet" >
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../css/wc.css">
    <link rel="import" href="../head/header.php">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/bootstrap.css">
    <title>Holiday Home Booking</title>
    <meta name="viewport" content="width-device-width,initial-scale=1.0 user-scale=no">
    <link rel="stylesheet" href="../../css/wc.css">
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet" >
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <style>
        body{
            padding-top:25px;
        }

    </style>
  </head>

<body>
<div class="container"><center><h1>Holiday Home Booking</h1</center></div>
<?php
      session_start();
      ?>  
    <div class="container">
    <a href="../EM/booking.php" class="btn btn-danger" type="" role="button">Back</a>
    <table align="right"> <tbody>
    <tr> 
    <td> <a href="../VR/vr.hh.room0.html" class="btn btn-primary btn-sm" role="button">View in VR</a></td>
    </tr>
    </tbody>
    </table>
    <form action="config/hh.php" method="post"> 
    <table align="center">
    <tbody>
    <tr>
        <td><label for="member">Emplyee ID:  </label></td>
        <td><p class="form-control-static"><?php echo "\n".$_SESSION["empid"];?></p></td>
      </tr>
    <tr>
        <td><label for="member">Name: </label></td>
        <td><p class="form-control-static"><?php echo "\n".$_SESSION["name"];?></p></td>
      </tr>
      <tr>
        <td><label for="member">Phone No. </label></td>
        <td><input class="form-control" type="text" name="phoneno"  placeholder="Enter Phone No." required/></td>
      </tr>
      <tr>
        <td><label for="member">Email Id: </label></td>
        <td><input  class="form-control" type="text" name="emailid"  placeholder="Enter Email ID" required/></td>
      </tr>
      <tr>
          <td>
          <label>Select Locations: </label> 
          </td>
          <td><select class="form-control" name="lctn">
                <option>udaipur</option>
                <option>jaipur</option>
                <option>Jodhpur</option>
                <option>Kota</option>
                <option>Ajmer</option>
              </select>
            </td>
      </tr>
      <tr>
        <td> <center><h5>Arival</h5> </center></td>
      </tr>
      <tr>
        <td> <label for="date"> Check in Date :</label></td>
        <td> <input class="form-control" type="date" name="indate" required/><br></td>
        
      </tr>
      <tr>
        <td><center><h5>Departs</h5></center></td>
      </tr>
      <tr>
        <td><label for="date">Check out Date :   </label></td>
        <td><input class="form-control" type="date" name="outdate" required/></td>
      </tr>
    </tbody>
</table>
<br>
  <table align="center">
  <tbody>
        <tr>
        <td><button type="reset" class="btn btn-danger btn-sm">Reset All</button></td>
        <td><button  id="" type="submit" class="btn btn-danger btn-sm">Check  Availablity</button ></td>
       
      </tr></tbody>
    </table>
    </form>
    </div>
    </center>
    </div>
    
    
    
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>
