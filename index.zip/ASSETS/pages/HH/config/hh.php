<?php
include("../../EM/config/connect.php");

session_start();
$x = 5; // Amount of digits
$min = pow(10,$x);
$max = pow(10,$x+1);
$value = rand($min, $max);
$_SESSION['bo_id'] = $value; 

$_SESSION['locaa'] = $_POST['lctn'];
$e_id = $_SESSION["empid"];
$name = $_SESSION["name"];
$cla = $_SESSION["class"];
$phoneno = $_POST['phoneno'];
$email = $_POST['emailid'];
$lctn = $_POST['lctn'];
$ind = $_POST['indate'];
$otd = $_POST['outdate'];
$menb = 5;
$count=0;
$rom_id = 1;
$z=array();
$typee ="Holiday Home";


$time = strtotime($_POST['indate']);
$time1 = strtotime($_POST['outdate']);
$time3=  date("Y-m-d");
$time3= strtotime($time3);
if ((($time-$time3)<=0)or(($time1-$time3)<=0))
{
    header("Location: dateerr.php");

}
else {
    if (($time1-$time)<0)
{
    header("Location: dateerr.php");
}
else{
    echo "corect date";
    $loca = $lctn."_hh";
    echo $loca;
    $sql3 = "INSERT INTO emp_history(emp_id,emp_name,b_id,locatn,_from,_to) VALUES ('$e_id','$name','$value','$lctn','$ind','$otd')";
if (mysqli_query($con,$sql3)){
    //echo "\n Data Inserted";
}
else{
    echo "Data Not Instered... !!!!!!!!!!! Something Wrong Happend";
}
    $sql = "SELECT res_flag FROM $loca where res_flag='0' ";
    $result = $con->query($sql);
    $count=0;
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            if ($row["res_flag"]==0)
            {

                //array_push($row["room_id"]);
                $count++;

            }

        }
        echo "\n".$count;
    }

    else{
        echo "\n Zero Entries";
    }
        

    if ($count>=1)
    {

        header("Location: ../confirm.php");
    }
    else
    { 
        echo "\n Not Available";
    }
}
}



?>