<!DOCTYPE html>
<html>
<head>

    <title>Request A cancellation </title>
    <meta name="viewport" content="width-device-width,initial-scale=1.0 user-scale=no">
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="../../css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link rel="stylesheet" href="../../css/wc.css">
    <link rel="stylesheet" href="../../css/main.css">
    <style>
        body{
            padding-top:25px;
        }
        .container{
          padding-top:25px;
          padding-bottom:25px;
        }

    </style>
    </head>
    <body>
        <div class="container">
          
          <form action="config/cancellation.php" method="post">
          <div class=:"row">
          <div class="col-md-5"><label>Enter Booking ID : </label> </div>
          <div class="col-md-5"><input type="tel" class="form-control" placeholder="Enter Booking ID" name="bid" required ><br><br></div>
          <div class="col-md-2"><input type="submit" value="Submit"></div>
          </form>
          </div>
        
        </div>



    </body>
</html>