<?php
include("../EM/config/connect.php");
session_start();
//$_SESSION['ama'] = $_POST['amnt']; //get input text
//$_SESSION['pay'] = $_POST['typpay'];
$value = $_SESSION['bo_id']; 
$loca = $_SESSION['locaa'];;
//mysqli_query($con,"UPDATE $lcctn set pay='1' where b_id='$value'");


//mysqli_query($con,"UPDATE emp_history set mo_pay=$typay AND amount=$amnt where b_id='$value'");
//mysqli_query($con,"INSERT INTO emp_history(e_id,b_id,c_name,Phone_no,email_id,loctn,in_date,out_date,rooms) VALUES ('$e_id','$value','$name','$phoneno','$email','$lctn','$ind','$otd','$days')";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../css/wc.css">
    <link rel="stylesheet" href="../..//css/main.css">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/bootstrap.css">
    <meta name="viewport" content="width-device-width,initial-scale=1.0 user-scale=no">
    <title>Confirmation</title>
    <script>
    history.pushState(null, null, location.href);
    window.onpopstate = function () {
        history.go(1);
    };
    </script>
</head>
<body>
    <div class="container">
        <br><br>
        <center><h2>CONFIRMED</h2></center>
    <br><br>
    <div class="container">
        
    <h4>The Invoice has been Mailed on the given mail Address</h4>
    <center><h4><p> The Booking ID is 
    <?php 
    echo $value;
    ?></p></h4></center>
    <h5 class="highlight">* The booking ID and all necessary Details has been Mailed. </h5>
    <a href="../EM/welcome.php" class="btn btn-primary btn-sm">Home </a>
    <a href="../EM/logout.php" class="btn btn-primary btn-sm">Log Out </a>
    </div>
    </div>
        <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>
