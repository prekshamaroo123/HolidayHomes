<?php
    header("refresh:2; url=../resthouse.php");
?>
     
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../../css/bootstrap.css">
    <link rel="stylesheet" href="../../../css/index.css">
    <link rel="stylesheet" href="../../../css/main.css">
    <title>Invaild Date</title>
    <style>
        body{
            padding-top:25px;
        }
        .container{
            padding-bottom: 25px;
        }

    </style>
</head>
<body>
        <div class="container" ><br><br>
                    <div class="alert alert-danger" role="alert">       
                    <center><h4>Entered Invaild Date </h4></center>
                    <h5>You Have Entered A Invaild Date  ! Try Again With A vaild Date !!!!! </h5>
                    
                    </div>
            </div>  
  </body>
</html>
