<?php
include("../../EM/config/connect.php");
session_start();
$x = 5; // Amount of digits
$min = pow(10,$x);
$max = pow(10,$x+1);
$value = rand($min, $max);
$_SESSION['bo_id'] = $value; 
$_SESSION["typr"] = $_POST["typ"];
$_SESSION['locale'] = $_POST['lctn'];
$e_id = $_SESSION["empid"];
$name = $_SESSION["name"];
$cla = $_SESSION["class"];
$typr = $_POST["typ"];

$phoneno = $_POST['phoneno'];
$email = $_POST['emailid'];
$lctn = $_POST['lctn'];
$_SESSION['from_'] = $_POST['indate'];
$_SESSION['to_'] = $_POST['outdate'];
$ind = $_POST['indate'];
$otd = $_POST['outdate']; 
$menb = 5;
$count=0;
$typyes = "Rest House";
$rom_id = "1";
$res_s = "1";
$time = strtotime($_POST['indate']);
$time1 = strtotime($_POST['outdate']);
$time3=  date("Y-m-d");
$time3= strtotime($time3);
$time2=$time1-$time;
$time4=($time2/86400)+1;
if ((($time-$time3)<0)or(($time1-$time3)<0))
{
    header("Location: ../confirmed.php");

}
else {
    if (($time1-$time)<0)
{
    header("Location: ../confirmed.php");
}
else{
    if($time4>3){
        header("Location: ../confirmed.php");;
    }
    else{
    $loca = $lctn."_rh";
    
$sql3 = "INSERT INTO emp_history(emp_id,emp_name,b_id,typee,locatn,_from,_to) VALUES ('$e_id','$name','$value','$typyes','$lctn','$ind','$otd')";
if (mysqli_query($con,$sql3)){
    //echo "\n Data Inserted";
}
else{
    echo "Data Not Instered... !!!!!!!!!!! Something Wrong Happend";
}
    
    
    
$sql = "SELECT res_flag FROM $loca where res_flag='0' ";
    $result = $con->query($sql);
    $count=0;
    if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        if ($row["res_flag"]==0)
        {
            
            //array_push($row["room_id"]);
            $count++;
        
        }
        
    }
    echo "\n".$count;
}

else
    echo "";

    if ($count>=1)
{
    header("Location: ../confirm.php");
}
    else
    { 
         header("Location: ../notconfirm.php");
}
        
    }
    
}
}

?>