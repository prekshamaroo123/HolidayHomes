<!DOCTYPE html>
<html>
<head>

    <title>Confirm A cancellation </title>
    <meta name="viewport" content="width-device-width,initial-scale=1.0 user-scale=no">
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="../../../css/bootstrap.min.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link rel="stylesheet" href="../../../css/wc.css">
    <link rel="stylesheet" href="../../../css/main.css">
    <style>
        body{
            padding-top:25px;
        }
        .container{
          padding-top:25px;
          padding-bottom:25px;
        }

    </style>
    </head>
    <body>
        <div class="container">
            <?php

            include("conr.php");

            //starting our session to preserve our login
            session_start();
            //check whether data with the name username has been submitted
            if (isset($_POST['bid'])) {

                //variables to hold our submitted data with post
                $book_id = $_POST['bid'];
                $_SESSION['b_id'] = $_POST['bid'];
                $sql = "SELECT * FROM udaipur WHERE b_id='$book_id'";
                $result = mysqli_query($con,"SELECT * FROM udaipur WHERE b_id='$book_id'");
                $re = mysqli_query($con, $sql);

                //check to see if there is any record or row in the database if there is then the user exists
                if (mysqli_num_rows($re)) {
                    while($row = mysqli_fetch_array($result)){
                    {
                        echo "Your Employee ID is".$row["e_id"]."\n";
                        echo "Your Booking is From date".$row["_from"]."\n";
                        echo "Your Booking is To date".$row["_to"];
                        
                    }
                        
                        }}
                else{
                            echo "The Booking Id Does Not Exist or Is Has Been Already Cancelled";
                        }}

                ?>
            <html>
            <a href="cancelf.php" class="btn btn-primary btn-sm">Confirm Cancellation </a>
            
            </html>
                    