<?php
include("conr.php");
session_start();


//check whether data with the name username has been submitted
if (isset($_SESSION['empid'])) {

	//variables to hold our submitted data with post
	$emp_id = $_SESSION['empid'];
        
	//our sql statement that we will execute
	$sql = "SELECT * FROM rh_log WHERE emp_id='$emp_id'";
    $result = mysqli_query($con,"SELECT * FROM rh_log WHERE emp_id='$emp_id'");
   
	//Executing the sql query with the connection
   
    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
        <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../../css/wc.css">
    <link rel="stylesheet" href="../../../css/main.css">
    <link rel="stylesheet" href="../../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../../css/bootstrap.css">
    <meta name="viewport" content="width-device-width,initial-scale=1.0 user-scale=no">
    <title>Hoilday Home - Previous Booking Record </title>
    <style>
        body{
            padding-top:25px;
        }
        .container{
            padding-top:25px;
            padding-bottom:25px;
        }
    </style>
</head>
<body>
    <div class="container">
        <center><h2>Hoilday Home Booking Record</h2></center>
    <a href="../../EM/history.php" class="btn btn-danger" type="" role="button">Back</a><br><br>
<table  class="table table-hover">
    <thead>
        <tr>
        <th>S. No</th>
        <th>Booking Id </th>
        <th>Date Of Booking</th>
        <th>Location</th>
        <th>Days</th>
        <th>Arrival Date</th>
        <th>Derpart Date</th>
        <th>Room No. </th>
        <th>Amount Paid</th>
        <th>MODE OF Payment</th></tr>
    </thead>
    <?php
     $re = mysqli_query($con, $sql);
     if (mysqli_num_rows($re)) {
         $i=1;
         while($row = mysqli_fetch_array($result)){ 
            
 {
    ?>
    <tbody>
        <tr>
            <td><?php echo $i ?></td>
            <td><?php echo $row["b_id"];?></td>
            <td><?php echo $row["date_of_booking"];?></td>
            <td><?php echo $row["locatn"];?></td>
            <td><?php echo $row["dayss"];?></td>
            <td><?php echo $row["_from"];?></td>
            <td><?php echo $row["_to"];?></td>
            <td><?php echo $row["room_id"];?></td>
            <td><?php echo $row["amount"];?></td>
            <td><?php echo $row["mo_pay"];?></td>
        </tr> 
            <?php    
                 $i++; 
                }
                }
                        }
                else{
                            echo "NO BOOKING RECORD FOUND";
                        }
            }
            ?>
                
    </tbody>
</table>
</div>
</body>
</html>
