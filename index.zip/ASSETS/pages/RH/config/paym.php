<?php
include("../../EM/config/connect.php");
session_start();
$value = $_SESSION['bo_id'];
$fro = $_SESSION['from_'];
$too = $_SESSION['to_'];
//$pad = $_POST['paytam'];
$pad = '30';
$typpay =  $_POST['mopay'];
$loca = $_SESSION['locaa'];
$locca =$loca."_rh";
$ress = "1";
echo $value;
echo $pad;
echo $typpay;

mysqli_query($con,"UPDATE emp_history set mo_pay='$typpay' where b_id='$value'");
mysqli_query($con,"UPDATE emp_history set amount='$pad' where b_id='$value'");
header("Location: ../confirmed.php");


//mysqli_query($con,"INSERT INTO $locca(b_id,_from,_to,res_flag) VALUE ('$value','$fro','$too','$ress') ");
//mysqli_query($con,"INSERT INTO emp_history mo_pay='$typpay' AND amount='$pad' WHERE b_id='$value'");
/*$sql1 = "UPDATE emp_history set mo_pay=$typpay AND amount=$pad where b_id='$value'";
if (mysqli_query($con,$sql1)){
    echo "done1";
}
else{
    echo "Data Not Instered... Something Wrong Happend";
}
$sql2 = "UPDATE emp_history set mop='$typpay' where b_id='$value'";
    if (mysqli_query($con,$sql2)){
        //header("Location: ../confirmed.php");
        echo "234";
    }
    else{
        echo "Data Not Instered 2... Something Wrong Happend";
    }
*/
//mysqli_query($con,"UPDATE emp_history set mo_pay=$typay AND amount=$amnt where b_id='$value'");
//mysqli_query($con,"INSERT INTO emp_history(e_id,b_id,c_name,Phone_no,email_id,loctn,in_date,out_date,rooms) VALUES ('$e_id','$value','$name','$phoneno','$email','$lctn','$ind','$otd','$days')";
?>