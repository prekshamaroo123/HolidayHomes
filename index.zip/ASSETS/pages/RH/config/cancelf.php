<?php
include("conr.php");
session_start();
$value = $_SESSION['b_id']; 
mysqli_query($con,"UPDATE udaipur SET cancel='1' Where b_id='$value'");
mysqli_query($con,"UPDATE udaipur SET res_flag='0' Where b_id='$value'");
mysqli_query($con,"UPDATE udaipur SET b_id='0' Where b_id='$value'");
?>
<!DOCTYPE html>
<html>
<head>

    <title>Confirm Cancellation</title>
    <meta name="viewport" content="width-device-width,initial-scale=1.0 user-scale=no">
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="../../../css/bootstrap.min.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link rel="stylesheet" href="../../../css/wc.css">
    <link rel="stylesheet" href="../../../css/main.css">
    <style>
        body{
            padding-top:25px;
        }

    </style>
    </head>
    <body>
        <div class="container">
        <p>Your Booking Is successfully Cancelled </p>

        </div>



    </body>
</html>
