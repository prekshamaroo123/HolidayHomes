<DOCTYPE html>
<html>
    <head>
        <title> Availibilty - Holiday Homes </title>
         <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../../css/wc.css">
    <link rel="stylesheet" href="../../../css/main.css">
    <link rel="stylesheet" href="../../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../../css/bootstrap.css">
    <meta name="viewport" content="width-device-width,initial-scale=1.0 user-scale=no">
        <style>
        body{
            padding-top:25px;
        }
        .container{
            padding-top:25px;
            padding-bottom:25px;
        }

    </style>
    </head>
    <body>       
        <div class="container"><center>
            <h3>Availibilty Of Rest House </h3>
            <p>the number of rooms availble in holiday homes </p></center>
            <a href="../../EM/avbl.php" class="btn btn-danger" type="" role="button">Back</a><br><br>
            <center><form action="" mrthod="post">
                <label for="">Choose Date : </label>
                <input type="date" name="c_date" />
                <button type="submit" class="btn btn-info btn-sm">Check</button>
            </form></center>

        </div>
        <div class="container">
        <table class="table table-borderd">
        <thead>
            <tr>
                <td>
                    S No.
                </td>
                <td>
                    Location 
                </td>
                <td>
                    Available Rooms
                </td>

            </tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    1.
                </td>
                <td>
                <a href="http://tourism.rajasthan.gov.in/jaipur.html">Jaipur</a>
                </td>
                <td>
                <?php
                        include("connect.php");
                        $sqla = "SELECT res_flag FROM jaipur ";
                        $sqlz = "SELECT pay FROM jaipur_log ";
                        $resulta = $con->query($sqla);
                        $result1z = $con->query($sqlz);
                        $counta=0;
                        $count1z=0;
                        if ($resulta->num_rows > 0) {
                        while($rowa = $resulta->fetch_assoc()) {
                            if ($rowa["res_flag"]==0)
                            {
                                //echo $row["id"];
                                $counta++;
                            }
                            
                            }}
                        if ($result1z->num_rows > 0) {
                        while($rowa = $result1z->fetch_assoc()) {
                            if ($rowa["pay"]==1)
                            {
                                //echo $row["id"];
                                $count1z++;
                            }
                            
                            }}
                            echo $counta-$count1z; ?>
                </td>
                <td>
                    <a href="../resthouse.php"> BOOK </a>
                </td>
            </tr>
            <tr>
                <td>
                    2.
                </td>
                <td>
                <a href="http://tourism.rajasthan.gov.in/udaipur.html">Udaipur</a>
                </td>
                <td>
                                    <?php
                                
                    $sql = "SELECT res_flag FROM udaipur ";
                        $sql1 = "SELECT pay FROM udaipur_log ";
                        $result = $con->query($sql);
                        $result1 = $con->query($sql1);
                        $count=0;
                        $count1=0;
                        if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            if ($row["res_flag"]==0)
                            {
                                //echo $row["id"];
                                $count++;
                            }
                            
                            }}
                        if ($result1->num_rows > 0) {
                        while($row = $result1->fetch_assoc()) {
                            if ($row["pay"]==1)
                            {
                                //echo $row["id"];
                                $count1++;
                            }
                            
                            }}
                            echo $count-$count1; ?>
                </td>
                <td>
                    <a href="../resthouse.php"> BOOK </a>
                </td>
            </tr>
            
        </tbody>


        </table>
        </div>

    </body>
</html>