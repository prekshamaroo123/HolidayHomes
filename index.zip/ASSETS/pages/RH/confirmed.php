<?php
$con =mysqli_connect('127.0.0.1','root','','bms');
if (mysqli_connect_errno()){
header("Location: dber.php");
}
session_start();
// Check connection for any errors

$bid = $_SESSION['bo_id'];
$fromm = $_SESSION['from_'];
$too = $_SESSION['to_'];
$fromm1 = $fromm;
$too1 = $too;
$fromm1 = strtotime($fromm);
$too1 = strtotime($too);
$time1=$fromm1-$too1;
$time2=($time1/86400)+1;
$sql="SELECT MIN(id) FROM udaipur_rh WHERE res_flag=0";
$result = mysqli_query($con,"SELECT * FROM udaipur_rh WHERE res_flag=0");
   //Executing the sql query with the connection
	$re = mysqli_query($con, $sql);
	//check to see if there is any record or row in the database if there is then the user exists
	if (mysqli_num_rows($re)) {
                while($row = mysqli_fetch_array($result)){
        {
            
            echo ($row["room_id"]);
            $rid = $row["room_id"];
            $qaz = $row["id"];
            mysqli_query($con,"UPDATE udaipur_rh SET b_id='$bid' WHERE id='$qaz'");
            mysqli_query($con,"UPDATE udaipur_rh SET res_flag='1' WHERE b_id='$bid'");
            mysqli_query($con,"UPDATE udaipur_rh SET _from='$fromm' WHERE b_id='$bid'");
            mysqli_query($con,"UPDATE udaipur_rh SET _to='$too' WHERE b_id='$bid'");
            mysqli_query($con,"UPDATE emp_history SET room_id='$rid' WHERE b_id='$bid'");
            mysqli_query($con,"UPDATE emp_history SET dayss='$time2' WHERE b_id='$bid'");
            break;
            
        }
    }
         	}
    else{
		        header("location: notconfirm.php");
	        }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../css/wc.css">
    <link rel="stylesheet" href="../../css/main.css">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/bootstrap.css">
    <meta name="viewport" content="width-device-width,initial-scale=1.0 user-scale=no">
    <title>Confirmation</title>
    <script>
    history.pushState(null, null, location.href);
    window.onpopstate = function () {
        history.go(1);
    };
    </script>
   
</head>
<body>
    <div class="container">
        <br><br>
        <center><h2>CONFIRMED</h2></center>
    <br><br>
    <div class="container">
        
    <h4>The Invoice has been Mailed on the given mail Address</h4>
    <center><h4><p> The Booking ID is 
    <?php 
    echo $bid;
    ?></p></h4></center>
    <h5 class="highlight">* The booking ID and all necessary Details has been Mailed. </h5>
         <h5 class="highlight">This is not The Confirmation. A confirmation Mail Will be Sent To you After Confirmation from the Higher Authorities </h5>
    <a href="../EM/welcome.php" class="btn btn-primary btn-sm">Home </a>
    <a href="../EM/logout.php" class="btn btn-primary btn-sm">Log Out </a>
    </div>
    </div>
        <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>
