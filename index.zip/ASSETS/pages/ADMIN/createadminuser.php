<?php

//MySQLi connection
$con =mysqli_connect('127.0.0.1','root','','adm');

// Check connection for any errors
if (mysqli_connect_errno()){
echo "Failed to connect to MySQL: ".mysqli_connect_error();
}

$admin_id = $_POST['adminid'];
$admin_pass= ($_POST['adminpass']);
$admin_name = ($_POST['adminname']);
$admin_age= ($_POST['adminage']);
mysqli_query($con,"INSERT INTO admin_details(a_id,name,pswd) VALUES ('$admin_id','$admin_name','$admin_pass')");
if(mysqli_affected_rows($con) > 0){
	echo "Admin Created";} 
else {
	echo "NOT Created";
	echo mysqli_error ($con);
}