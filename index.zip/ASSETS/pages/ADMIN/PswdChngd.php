<!DOCTYPE html>
<html>
<head>

    <title>Welcome to IRCTC Online Booking</title>
    <meta name="viewport" content="width-device-width,initial-scale=1.0 user-scale=no">
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet" >
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../css/wc.css">
    <link rel="stylesheet" href="../../css/main.css">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/bootstrap.css">
    <style>
        body{
            padding-top:25px;
        }
        .container{
            padding-bottom: 25px;
        }

    </style>    
</head>
    
    <body>
        <div class="container"><br><br>
            <div class="alert alert-success" role="alert">       
            <h4>You have succesfully Changed Your Password.</h4>
            </div>
    </div>    
    </body>
    <?php
    session_start();
    session_destroy();
    header("refresh:4; url=../../../index.html");
    ?>

    
</html>