<?php

//MySQLi connection
$con =mysqli_connect('127.0.0.1','root','','emp');

// Check connection for any errors
if (mysqli_connect_errno()){
echo "Failed to connect to MySQL: ".mysqli_connect_error();
}
$emp_id = $_POST['empid'];
$emp_pass = $_POST['emppass'];
$emp_name = $_POST['empname'];
$emp_rank = $_POST['emprank'];
$emp_age = $_POST['empage'];
$emp_doj = $_POST['empdoj'];
$emp_dor = $_POST['empdor'];
mysqli_query($con,"INSERT INTO emp_details(emp_id,emp_name,class,age,doj,dor,pswd) VALUES ('$emp_id','$emp_name','$emp_rank','$emp_age','$emp_doj','$emp_dor','$emp_pass')");
if(mysqli_affected_rows($con) > 0){
	header("Location: empcreated.php")} 
else {
	echo "NOT Created";
	echo mysqli_error ($con);
}