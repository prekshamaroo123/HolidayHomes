<?php

//MySQLi connection
$con =mysqli_connect('127.0.0.1','root','','bms');

// Check connection for any errors
if (mysqli_connect_errno()){
echo "Failed to connect to MySQL: ".mysqli_connect_error();
}
 $sql = "SELECT * FROM jaipur_rh ";
 $result = $con->query($sql);
 $count=0;
 $total=20;
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        if ($row["res_flag"]==1)
        {
            //echo $row["id"];
            $count++;
         
        }
        
    } 
    echo $total;
//    echo $count;
    echo $total-$count;}
   
    else
        echo "Zero Entries";

    $sql1 = "SELECT * FROM jaipur_rh WHERE res_flag='1' ";
    $result1 = mysqli_query($con,"SELECT * FROM jaipur_rh WHERE res_flag='1'");
    $re = mysqli_query($con, $sql1);

	//check to see if there is any record or row in the database if there is then the user exists
	if (mysqli_num_rows($re)) {
                echo "<p>Welcome</p>";
                while($row = mysqli_fetch_array($result1)){
        {
            echo $row["room_id"];
            echo "<br>";
            echo $row["b_id"];
            echo "<br>";
            echo $row["_from"];
            echo "<br>";
            echo $row["_to"];
            echo "<br>";
            
        }
    }
         	}