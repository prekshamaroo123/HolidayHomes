<!DOCTYPE html>
<html>
<head>
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet" >
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../css/wc.css">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/bootstrap.css">
    <meta name="viewport" content="width-device-width,initial-scale=1.0 user-scale=no">
    <link rel="stylesheet" href="../../css/wc.css">
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <title>Add Rest House</title>
    </head>
        <body>
            <?php
        include('../../head/header.html');
        ?>
            <div class="container">
         <name class="row">
             <div class="col-md-3">
                     <a href="Admin.php"><img src="../../imgs/logo.png"alt="IRCTC" height=100 width=auto></a>
            </div>
            <div class="col-md-9">
            <h1>Add Rest House</h1>
            </div>
            </name>
                
    
                    <form action="config/nrh.php" method="post">

<table align="center";>
    <tr>
    <td>
        <label>Select Location: </label>
        </td>
        <td><select class="form-control" name="lctn">
            <option>udaipur</option>
            <option>jaipur</option>
            </select>
                
        </td>
    </tr>
    
    <tr>
    <td>
        <label>Select Room type:  </label>
        </td>
        <td><select class="form-control" name="typ">
            <option>A/C</option>
            <option>Non A/C</option>
            </select>
                
        </td>
    </tr>
        <tr>
        <td><label for="member">Room ID: </label></td>
        <td><input class="form-control" type="digit" name="roomid" id="mem" placeholder="Enter Room ID" required/></td>
      </tr>     
    <tr>
    <td>
        <input class="btn btn-default"  type="submit" value="Submit">

        </td>
    </tr>
        </table>
                       
  </form>
                
                
            </div>
             <?php
        include('../../head/footer.html');
        ?>
    </body>
</html>