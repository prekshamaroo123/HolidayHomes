<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
        <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet" >
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../css/wc.css">
    <link rel="stylesheet" href="../../css/main.css">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/bootstrap.css">
    
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    
    <link rel="stylesheet" href="../../css/displayemployeeusers.css">
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">

    <meta name="viewport" content="width-device-width,initial-scale=1.0 user-scale=no">
    <title>Employee List </title>
    <style>
        body{
            padding-top:25px;
        }
        .container{
            padding-top:25px;
            padding-bottom:25px;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="Admin.php" class="btn btn-primary"><i style="font-size:40px;" class="fa fa-chevron-circle-left"></i></a>
        <center><h2>Employee List</h2></center>
    <br><br>
        <center><h4><b>List of the Employee are as follow</b></h4></center>
<table  class="table table-hover">
    <thead>
        <tr>
        <td>S. No</td>
        <td>Emp ID</td>
        <td>Rank</td>
        <th>Name</th>
        <th>Age</th>
        <th>Date of Joining</th>
        <th>Date of Resign</th>
        <th>Password</th>
        <th>Birth place</th>
        <th>Pet Name</th></tr>
    </thead>
    <?php
    $con =mysqli_connect('127.0.0.1','root','','emp');

// Check connection for any errors
if (mysqli_connect_errno()){
echo "Failed to connect to MySQL: ".mysqli_connect_error();
}
$sql = "SELECT * FROM emp_details ";
    $result = mysqli_query($con,"SELECT * FROM emp_details ORDER BY doj DESC");
   
	//Executing the sql query with the connection
	$re = mysqli_query($con, $sql);

	//check to see if there is any record or row in the database if there is then the user exists
	if (mysqli_num_rows($re)) {
                $i =1;
                while($row = mysqli_fetch_array($result))
            
 {
    ?>
    <tbody>
        <tr>
            <td><?php echo $i; ?> </td>
            <td><?php echo $row["emp_id"]; ?> </td>
            <td><?php echo $row["class"]; ?></td>
            <td><?php echo $row["emp_name"]; ?> </td>
            <td><?php echo $row["age"]; ?> </td>
            <td><?php echo $row["doj"]; ?> </td>
            <td><?php echo $row["dor"]; ?> </td>
            <td><?php echo $row["pswd"]; ?> </td>
            <td><?php echo $row["ans1"]; ?> </td>
            <td><?php echo $row["ans2"]; ?> </td>
           
            
        
        </tr> 
            <?php 
                     $i++;}
        
                }
            ?>
                
    </tbody>
</table>
</div>
</body>
</html>


