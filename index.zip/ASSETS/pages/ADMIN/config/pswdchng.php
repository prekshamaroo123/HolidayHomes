<?php
            include("connect.php");
            session_start ();
      $oldpass=$_POST['opwd'];
      $useremail=$_SESSION['empid'];
      $newpassword=$_POST['npwd'];
      $sql = mysqli_query($con,"SELECT pswd FROM emp_details where emp_id='$useremail'");
      
      $row = mysqli_fetch_array($sql);
      $op = $row["pswd"];
      if($op == $oldpass)
      {
      mysqli_query($con,"UPDATE emp_details set pswd='$newpassword' where emp_id='$useremail'");
      
      header("Location: ../PswdChngd.php");
      }
      else
      {
      header("Location: ../ErPswdChngd.php");
      }

?>