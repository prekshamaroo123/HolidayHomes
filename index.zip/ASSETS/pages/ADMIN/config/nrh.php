<?php
include("../../EM/config/connect.php");
session_start();
$rid = $_POST["r_id"];
$fea = $_POST['typ'];
$locaaa = $_POST['lctn'];
echo $loca;
$loca = $locaaa."_rh";
$sql3 = "INSERT INTO $loca(room_id,dcsr,res_flag) VALUES ('$rid','$fea','0')";
if (mysqli_query($con,$sql3)){
    //echo "\n Data Inserted";
}
else{
    echo "Data Not Instered... !!!!!!!!!!! Something Wrong Happend";
}
?>