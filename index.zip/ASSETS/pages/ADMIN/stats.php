<!DOCTYPE html>
<html>
<head>
    <!-- Bootstrap CSS -->
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet" >
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../css/wc.css">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/bootstrap.css">
    <meta name="viewport" content="width-device-width,initial-scale=1.0 user-scale=no">
    <link rel="stylesheet" href="../../css/wc.css">
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <title>Statistics</title>
    <style>
         body{
            padding-top:25px;
        }
        .container{
            padding-bottom: 10px;
        }

    </style>    
    </head>
    <?php
        include('../../head/header.html');
        ?>
        <body>
            <div class="container">
         <name class="row">
             <div class="col-md-3">
                     <a href="Admin.php"><img src="../../imgs/logo.png"alt="IRCTC" height=150 width=auto></a>
            </div>
            <div class="col-md-9">
            <h1>Statistics</h1>
            </div>
            </name>
               <!-- <card class="row text-center">
            <div class="card-deck">
               <a class="card" href="add.rh.rm.php" disabled>
    <img class="card-img-top" src="../../imgs/rest.jpg" height="200px" width="200px" alt="Card image cap">
    <div class="card-body">
      <h5 class="Rest House">Rest House</h5>
    </div>
                </a>
  <a class="card" href="add.hh.rm.php"  disabled>
    <img class="card-img-top" src="../../imgs/home.jpg" height="200px" width="200px" alt="Card image cap">
    <div class="card-body">
      <h5 class="Holiday Homes">Holiday Homes</h5>
    </div>
</a>
                <a class="card" href="statisticsudaipurrh.php" >
    <img class="card-img-top" src="../../imgs/rest.jpg" height="200px" width="200px" alt="Card image cap">
    <div class="card-body">
      <h5 class="Rest House">Rest House View</h5>
    </div>
                </a>
</div>
        </card>-->
                <a href="statisticsudaipurrh.php"> Stats of Rest House.</a>
            </div>
            <?php
        include('../../head/footer.html');
        ?>
    </body>
</html>