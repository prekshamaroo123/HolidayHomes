<?php 
session_start();


?>

<!DOCTYPE html>
<html>
<head>
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet" >
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../css/wc.css">
    <link rel="stylesheet" href="../../css/main.css">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/bootstrap.css">
    <title>Udaipur Admin Panel </title>
    <meta name="viewport" content="width-device-width,initial-scale=1.0 user-scale=no">
    <link rel="stylesheet" href="../../css/Admin.css">
   
    </head>
    <style>
        body{
            padding-top:55px;
        }

    </style>
    <body>
        <?php
        include('../../head/header.html');
        ?>
        <div class="container">
            <!--<nav class="row">
            <a class="col-md-3" href="accset.php">Account Settings</a>
            <a class="col-md-3" href="home.php">Booking</a>
            <a class="col-md-3" href="php/hist.php">History</a>
            <a class="col-md-3" href="logout.php">Log Out</a>
                        </nav>-->
            <name class="row">
             <div class="col-md-3">
                  <a href="Admin.php"><img src="../../imgs/logo.png"alt="IRCTC" height=150 width=auto></a>
            </div>
            <div class="col-md-9">
            <h1>UDAIPUR PANEL</h1>
            </div>
            </name>
        </div>
        <div class="container" style=padding-top:25px;>
            <div class="row">
            <div class="col-md-3"> 
                <div class="sidenav">
                    <table>
                        <tbody>
                        <tr>
                            <td>
                            <button class="btn btn-light"size=20><a href="AccountSetting.php"><i style="font-size: 35px;" class="fa fa-gear" aria-hidden="true"></i><b>Settings</b></a></button>
                            </td>
                        </tr>
                        <tr>
                            <!--<td>
                            <button class="btn btn-light" size=20><a href="createadminuser.html"><i style="font-size:35px;" class="fa fa-building" aria-hidden="true"></i><b>Create Admin</b></a></button>
                            </td>
                        </tr>
                        <tr>
                            <td>
                            <button class="btn btn-light" size=20><a href="createemployeeuser.html"><i style="font-size: 35px;" class="fa fa-home" aria-hidden="true"></i><b>Create Employee</b></a></button>
                            </td>
                        </tr>
                            <tr>
                            <td>
                            <button class="btn btn-light" size=20><a href="displayadminusers.php"><i style="font-size: 35px;" class="fa fa-history" aria-hidden="true"></i><b>Show Admins </b></a></button>
                            </td>
                        </tr>
                            <tr>
                            <td>
                            <button class="btn btn-light" size=20><a href="displayemployeeusers.php"><i style="font-size: 35px;" class="fa fa-remove" aria-hidden="true"></i><b>Show Employees</b> </a></button><br>
                            </td>
                        </tr>-->
                            <tr>
                                <td>
                            <button class="btn btn-light"size=20><a href="addroom.php"><i style="font-size: 30px;" class="fa fa-plus" aria-hidden="true"></i><b>ADD ROOMS</b></a></button>
                            </td>
                            </tr>
                            <tr>
                            <td>
                            <button class="btn btn-light"size=20><a href="rh.php"><i style="font-size: 30px;" class="fa fa-building" aria-hidden="true"></i><b>Rest House</b></a></button>
                            </td>
                            </tr>
                             <tr>
                            <td>
                            <button class="btn btn-light"size=20><a href="hh.php"><i style="font-size: 30px;" class="fa fa-home" aria-hidden="true"></i><b>Holiday Home</b></a></button>
                            </td>
                            </tr>
                            <tr>
                            <td>
                            <button class="btn btn-light"size=20><a href="stats.php"><i style="font-size: 30px;" class="fa fa-home" aria-hidden="true"></i><b>Stats </b></a></button>
                            </td>
                            </tr>
                            
                            <tr>
                            <td>
                                <button class="btn btn-light" size=20><a href="javascript:myFunction()" color="red"><i style="font-size: 35px;" class="fa fa-power-off" aria-hidden="true"></i><b>Log Out</b></a></button>
                            </td>
                        
                        </tr>
                        </tbody>
        </table>        
                </div>
            </div>
            <div class="col-md-9">
        <div class="alert alert-success" role="alert">
            <h2 class="alert-heading"><b> Welcome </b></h2>
  <h4>You have succesfully logged in to your account.</h4>
  <hr>
              </div>
            </div>
            </div>
            </div>
        <script>
        function myFunction() {
            if (confirm("Are You Sure You Want To Log Out ")) {
                txt = "You Successfully Logged Out";
                document.location = 'logout.php';
                
               // document.location = 'php/lgt.php';
            } else {
                txt = "You are not Logged Out";
            }
        }
    </script>
        <?php
        include('../../head/footer.html');
        ?>
    </body>
    
</html>