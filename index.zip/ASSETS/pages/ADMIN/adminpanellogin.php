<?php

//MySQLi connection
$con =mysqli_connect('localhost','root','','adm');

// Check connection for any errors
if (mysqli_connect_errno()){
echo "Failed to connect to MySQL: ".mysqli_connect_error();
}
    
    $admin_id = $_POST['adminid'];
	$admin_pass= ($_POST['adminpass']);

	//our sql statement that we will execute
	$sql = "SELECT * FROM admin_details WHERE a_id='$admin_id' AND pswd='$admin_pass'";

	//Executing the sql query with the connection
	$re = mysqli_query($con, $sql);

	//check to see if there is any record or row in the database if there is then the user exists
	if (mysqli_num_rows($re)){
        
                $_SESSION['aid'] = $admin_id;
		      //$_SESSION['name'] = $row["emp_name"];
		      //$_SESSION['class'] = $row["class"]; 

            //echo "<p>Welcome</p>";
            while($row = mysqli_fetch_array($re)){
            //echo "\n".$row["emp_id"];
            //echo "\n".$row["emp_name"];
			//echo "\n".$row["class"];
            $_SESSION['adid'] = $row["a_id"];
			$_SESSION['aname'] = $row["name"];
                header("Location: Admin.php");
            
    
            }
    }
    else{
                header("Location: Adminerror.php");
    }
?>
