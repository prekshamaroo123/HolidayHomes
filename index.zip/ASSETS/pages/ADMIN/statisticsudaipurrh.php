<!DOCTYPE html>
<html>
<head>

    <title>statistics</title>
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../css/wc.css">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/bootstrap.css">
    <meta name="viewport" content="width-device-width,initial-scale=1.0 user-scale=no">
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    </head>
    <style>
        body{
            padding-top:50px;
            padding-bottom:25px;
        }
        .container{
            padding-top:25px;
            padding-bottom: 25px;
        }
    </style>
    <body>
<div class="container">
        <center><h2>Rest House Booking View</h2></center>
    <a href="Admin.php" class="btn btn-danger" type="" role="button">Back</a><br><br>
<table  class="table table-hover">
    <thead>
        <tr>
        <th>S. No</th>
        <th>Room ID </th>
        <th>Booking ID</th>
        <th>Type</th>
    </tr>
    </thead>

<?php

//MySQLi connection
$con =mysqli_connect('127.0.0.1','root','','bms');

// Check connection for any errors
if (mysqli_connect_errno()){
echo "Failed to connect to MySQL: ".mysqli_connect_error();
}
 $sql = "SELECT res_flag,id FROM udaipur_rh ";
 $result = $con->query($sql);
 $count=0;
 $total=0;
 
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        if ($row["res_flag"]==1)
        {
            //echo $row["id"];
            $count++;
        }
        if ($row["id"]>0){
                    $total++;
                }
        
    } 
    echo "Total number of rooms =". $total;
    echo "<br>";
    echo "Number of rooms Booked=".$count;
    echo "<br>";
    echo "Number of rooms Available=".($total-$count);
    echo "<br>";
    ?>

    
    
    <?php
}
else
    echo "Zero Entries";
$sql1 = "SELECT * FROM udaipur_rh ";
$result1 = mysqli_query($con,"SELECT * FROM udaipur_rh");
$re = mysqli_query($con, $sql1);

	//check to see if there is any record or row in the database if there is then the user exists
if (mysqli_num_rows($re)) {
        while($row = mysqli_fetch_array($result1)){
            if ($row["res_flag"]==1){
     $re = mysqli_query($con, $sql);
     if (mysqli_num_rows($re)) {
         $i=0;
         while($row = mysqli_fetch_array($result1)){ 
             if ($row["res_flag"]==1){
            
                 
            
 
    ?>
    <tbody>
        <tr>
            <td><?php echo $i ?></td>
            <td><?php echo $row["room_id"]; ?></td>
            <td><?php echo $row["b_id"]; ?></td>
            <td><?php echo $row["dcsr"]; ?></td>
            <td><?php echo $row["_from"]; ?></td>
            <td><?php echo $row["_to"]; ?></td>
            <td><br><br><br>  </td>
        </tr> 
            <?php    
                 $i++; 
                }
         }
     }
                        }
                else{
                            echo "NO BOOKING RECORD FOUND";
                        }
            
            ?>
                
    </tbody>
</table>
</div>
</body>
</html>


<?php
            }
            
            
        }   ?>